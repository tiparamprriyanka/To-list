import React from 'react';
import { Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { GiWhiteBook } from 'react-icons/gi';
import { useNavigate } from 'react-router-dom';
import { authActions } from '../../store/index.js';

const Navbar = () => {
    const history = useNavigate();
    const isLoggedIn = useSelector((state) => state.isLoggedIn);
    const dispatch = useDispatch();

    const logout = () => {
        sessionStorage.clear('id');
        dispatch(authActions.logout());
        history("/");
    };

    return (
        <nav className="navbar navbar-expand-lg bg-body-tertiary">
            <div className="container-fluid">
                <a className="navbar-brand" href="/">
                    <GiWhiteBook /> &nbsp; List
                </a>
                <button
                    className="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarNavDropdown"
                    aria-controls="navbarNavDropdown"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                >
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul className="navbar-nav ms-auto">
                        <li className="nav-item">
                            <Link className="nav-link active" aria-current="page" to="/">
                                Home
                            </Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/about">
                                About Us
                            </Link>
                        </li>

                        {isLoggedIn && (
                            <li className="nav-item">
                                <Link className="nav-link" to="/todo">
                                    Todo
                                </Link>
                            </li>
                        )}

                        {!isLoggedIn && (
                            <li className="nav-item">
                                <Link className="nav-link" to="/signup">
                                    Sign Up
                                </Link>
                            </li>
                        )}

                        {!isLoggedIn && (
                            <li className="nav-item">
                                <Link className="nav-link" to="/signin">
                                    Sign In
                                </Link>
                            </li>
                        )}

                        {isLoggedIn && (
                            <li className="nav-item">
                                <Link className="nav-link" to="#" onClick={logout}>
                                    Log Out
                                </Link>
                            </li>
                        )}
                    </ul>
                </div>
            </div>
        </nav>
    )
}

export default Navbar;
