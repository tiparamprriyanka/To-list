import React from 'react'
import "./fotter.css"
const fotter = () => {
  return (
    <div className='container-fluid p-3 d-flex justify-content-center align-items-center text-dark fotter'>
         <p className='m-0'>Copy@Right</p>
        </div>
  )
}

export default fotter